<?php

if (!defined('ABSPATH')) exit;
if (!class_exists('ALInfo')) :
	class ALInfo {
		public $settings;
		public $config;
		public $plugname = 'airlift';
		public $brandname = 'AirLift';
		public $badgeinfo = 'albadge';
		public $ip_header_option = 'alipheader';
		public $brand_option = 'bv_whitelabel_infos';
		public $wp_lp_whitelabel_option = 'alLpWhitelabelConf';
		public $version = '6.77';
		public $webpage = 'https://airlift.net';
		public $appurl = 'https://app.airlift.net';
		public $slug = 'airlift/airlift.php';
		public $plug_redirect = 'alredirect';
		public $logo = '../img/airlift-white-logo.svg';
		public $brand_icon = '/img/icon.png';
		public $services_option_name = 'alconfig';
		public $author = 'AirLift';
		public $title = 'AirLift';

		const DB_VERSION = '5';
		const AL_CONF_VERSION = '1.1';

		public function __construct($settings) {
			$this->settings = $settings;
			$this->config = $this->settings->getOption($this->services_option_name);
		}

		public function getCurrentDBVersion() {
			$bvconfig = $this->config;
			if ($bvconfig && array_key_exists('db_version', $bvconfig)) {
				return $bvconfig['db_version'];
			}
			return false;
		}

		# The server leases capture for a few days at a time; a stale configuration
		# registers nothing.
		public function isActivityLogActive() {
			$config = isset($this->config['activity_log']) ? $this->config['activity_log'] : null;
			return $this->hasValidDBVersion() && is_array($config) && !empty($config['hooks']) &&
				isset($config['enabled_until']) && is_numeric($config['enabled_until']) && $config['enabled_until'] > time();
		}

		public function hasValidDBVersion() {
			return ALInfo::DB_VERSION === $this->getCurrentDBVersion();
		}

		public function getLatestWooCommerceDBVersion() {
			if (defined('WC_ABSPATH') && file_exists(WC_ABSPATH . 'includes/class-wc-install.php')) {
				include_once WC_ABSPATH . 'includes/class-wc-install.php';

				if (class_exists('WC_Install')) {
					$update_versions = array_keys(WC_Install::get_db_update_callbacks());

					if (!empty($update_versions)) {
						asort($update_versions);
						return end($update_versions);
					}
				}
			}

			return false;
		}

		public function getConnectionKey() {
			require_once dirname( __FILE__ ) . '/recover.php';
			$bvsiteinfo = new ALWPSiteInfo();
			$encoded_url = base64_encode($bvsiteinfo->siteurl());
			$secret = ALRecover::defaultSecret($this->settings);
			$tag = ALRecover::connectionTag($this->settings);

			#No tag means this site has no salt material in wp-config.php, and there
			#is no connection key that would be safe to hand out.
			if (empty($secret) || empty($tag)) {
				return null;
			}

			return base64_encode("v3:".$secret.":".$encoded_url.":".$this->plugname.":".$tag);
		}

		public function getLatestElementorDBVersion($file) {
			$managerClass = $file === "elementor/elementor.php" ? '\Elementor\Core\Upgrade\Manager' : '\ElementorPro\Core\Upgrade\Manager';

			if (!class_exists($managerClass)) {
				return false;
			}

			$manager = new $managerClass();
			return $manager->get_new_version();
		}

		public static function getRequestID() {
			if (!defined("AL_REQUEST_ID")) {
				define("AL_REQUEST_ID", uniqid(mt_rand())); // phpcs:ignore WordPress.WP.AlternativeFunctions.rand_mt_rand
			}
			return AL_REQUEST_ID;
		}

		public function canWhiteLabel($slug = NULL) {
			// phpcs:disable WordPress.Security.NonceVerification.Recommended
			if (array_key_exists("bv_override_global_whitelabel", $_REQUEST)) {
				return false;
			}
			if (array_key_exists("bv_override_plugin_whitelabel", $_REQUEST) && isset($slug) &&
				$_REQUEST["bv_override_plugin_whitelabel"] === $slug) {
				return false;
			}
			// phpcs:enable WordPress.Security.NonceVerification.Recommended
			return true;
		}

		public function getPluginWhitelabelInfo($slug = null) {
			if ($slug === null) {
				$slug = $this->slug;
			}
			$whitelabel_infos = $this->getPluginsWhitelabelInfos();
			if (!array_key_exists($slug, $whitelabel_infos) || !is_array($whitelabel_infos[$slug])) {
				return array();
			}
			return $whitelabel_infos[$slug];
		}

		public function getBrandInfo() {
			return $this->settings->getOption($this->brand_option);
		}

		public function getPluginsWhitelabelInfos() {
			$whitelabel_infos = $this->settings->getOption($this->brand_option);
			return is_array($whitelabel_infos) ? $whitelabel_infos : array();
		}

		public function getLPWhitelabelInfo() {
			$infos = $this->settings->getOption($this->wp_lp_whitelabel_option);
			return is_array($infos) ? $infos : array();
		}

		public function getPluginsWhitelabelInfoByTitle() {
			$whitelabel_infos = $this->getPluginsWhitelabelInfos();
			$whitelabel_infos_by_title = array();
			foreach ($whitelabel_infos as $slug => $whitelabel_info) {
				if (is_array($whitelabel_info) && array_key_exists('default_title', $whitelabel_info) && isset($whitelabel_info['default_title'])) {
					$whitelabel_info['slug'] = $slug;
					$whitelabel_infos_by_title[$whitelabel_info['default_title']] = $whitelabel_info;
				}
			}
			return $whitelabel_infos_by_title;
		}

		public function getBrandName() {
			$brand = $this->getPluginWhitelabelInfo();
			if (is_array($brand) && array_key_exists('menuname', $brand)) {
				return $brand['menuname'];
			}
			return $this->brandname;
		}

		public function getBrandIcon() {
			$brand = $this->getPluginWhitelabelInfo();
			if (is_array($brand) && array_key_exists('brand_icon', $brand)) {
				return $brand['brand_icon'];
			}
			return $this->brand_icon;
		}

		public function getWatchTime() {
			$time = $this->settings->getOption('bvwatchtime');
			return ($time ? $time : 0);
		}

		public function appUrl() {
			if (defined('BV_APP_URL')) {
				return BV_APP_URL;
			} else {
				$brand = $this->getPluginWhitelabelInfo();
				if (is_array($brand) && array_key_exists('appurl', $brand)) {
					return $brand['appurl'];
				}
				return $this->appurl;
			}
		}

		public function isActivePlugin() {
			$expiry_time = time() - (3 * 24 * 3600);
			return ($this->getWatchTime() > $expiry_time);
		}

		public function isValidEnvironment(){
			$bvsiteinfo = new ALWPSiteInfo();
			$bvconfig = $this->config;

			if (is_multisite()) {
				return true;
			} elseif ($bvconfig && array_key_exists("siteurl_scheme", $bvconfig)) {
				$siteurl = $bvsiteinfo->siteurl('', $bvconfig["siteurl_scheme"]);
				if (array_key_exists("abspath", $bvconfig) &&
						array_key_exists("siteurl", $bvconfig) && !empty($siteurl)) {
					return ($bvconfig["abspath"] == ABSPATH && $bvconfig["siteurl"] == $siteurl);
				}
			}
			return true;
		}

		public function isProtectModuleEnabled() {
			return $this->isServiceActive("protect") && $this->isValidEnvironment();
		}

		public function isDynSyncModuleEnabled() {
			if ($this->isServiceActive("dynsync")) {
				$dynconfig = $this->config['dynsync'];
				if (array_key_exists('dynplug', $dynconfig) && ($dynconfig['dynplug'] === $this->plugname)) {
					return true;
				}
			}
			return false;
		}

		public function isServiceActive($service) {
			$bvconfig = $this->config;
			if ($bvconfig && array_key_exists('services', $bvconfig)) {
				return in_array($service, $bvconfig['services']) && $this->isActivePlugin();
			}
			return false;
		}

		public function isActivateRedirectSet() {
			return ($this->settings->getOption($this->plug_redirect) === 'yes') ? true : false;
		}

		public function isMalcare() {
			return $this->getBrandName() === 'MalCare';
		}

		public function isBlogvault() {
			return $this->getBrandName() === 'BlogVault';
		}

		public function info() {
			return array(
				"bvversion" => $this->version,
				"sha1" => "true",
				"plugname" => $this->plugname
			);
		}
	}
endif;
