<?php

require_once dirname(__FILE__) . '/font_face_rewriter.php';
require_once dirname(__FILE__) . '/background_image_rewriter.php';

if (!class_exists('ALInlineStyleOptimizationHandler')) :

	class ALInlineStyleOptimizationHandler {
		private $extract_style_regex;
		private $font_rewriter;
		private $image_rewriter;
		private $tag_rewriter;

		public function __construct($config, $template_config) {
			$config = is_array($config) ? $config : array();
			$template_config = is_array($template_config) ? $template_config : array();
			$this->extract_style_regex = isset($config['extract_style_regex']) ? $config['extract_style_regex'] : '';
			$this->tag_rewriter = new ALImageTagRewriter();

			$this->font_rewriter = new ALInlineFontFaceRewriter(
				isset($config['extract_font_face_regex']) ? $config['extract_font_face_regex'] : '',
				isset($template_config['font_replace_rules']) ? $template_config['font_replace_rules'] : array(),
				$this->tag_rewriter
			);
			$this->image_rewriter = new ALInlineBackgroundImageRewriter(
				$config,
				isset($template_config['image']) ? $template_config['image'] : array(),
				$this->tag_rewriter
			);
		}

		public function optimizeUnmatchedStyleTags($buffer, $replacement_rules = array()) {
			if (!is_string($buffer) || !is_string($this->extract_style_regex) || $this->extract_style_regex === '' || (!$this->font_rewriter->canRewrite() && !$this->image_rewriter->canRewrite())) {
				return $buffer;
			}

			$configured_styles = $this->configuredStyleLookup($replacement_rules);
			return $this->tag_rewriter->safePregReplaceCallback($this->extract_style_regex, function($match) use ($configured_styles) {
				if (isset($configured_styles[$match[0]])) {
					return $match[0];
				}

				return $this->optimizeStyleTag($match[0]);
			}, $buffer);
		}

		public function optimizeStyleTag($style) {
			if (!is_string($style)) {
				return $style;
			}

			return $this->image_rewriter->rewrite($this->font_rewriter->rewrite($style));
		}

		private function configuredStyleLookup($replacement_rules) {
			$lookup = array();
			foreach (is_array($replacement_rules) ? $replacement_rules : array() as $rule) {
				if (is_array($rule) && isset($rule['search_for']) && is_string($rule['search_for'])) {
					$lookup[$rule['search_for']] = true;
				}
			}
			return $lookup;
		}
	}
endif;
