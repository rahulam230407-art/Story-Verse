<?php

require_once dirname(__FILE__) . '/variant_resolver.php';
require_once dirname(__FILE__) . '/responsive_source_builder.php';
require_once dirname(__FILE__) . '/tag_rewriter.php';

if (!class_exists('ALImageOptimizationHandler')) :

	class ALImageOptimizationHandler {
		const DEFAULT_REGEX_BACKTRACK_LIMIT = 250000;
		const DEFAULT_REGEX_RECURSION_LIMIT = 100000;
		const DEFAULT_PROTECTED_CONTENT_REGEX = '~<script\b[^>]*>[\s\S]*?(?:</script\s*>|\z)~i';

		private $config;
		private $image_config;
		private $url_matched;
		private $tag_rewriter;
		private $variant_resolver;
		private $responsive_source_builder;
		private $preload_links = array();
		private $preload_link_keys = array();

		public function __construct($config, $image_config, $url_matched = false) {
			$this->config = is_array($config) ? $config : array();
			$this->image_config = is_array($image_config) ? $image_config : array();
			$this->url_matched = (bool) $url_matched;
			$this->tag_rewriter = new ALImageTagRewriter();
			$this->variant_resolver = new ALImageVariantResolver($this->config, $this->image_config);
			$this->responsive_source_builder = new ALResponsiveImageSourceBuilder($this->variant_resolver);
		}

		public static function canHandle($config, $image_config) {
			$config = is_array($config) ? $config : array();
			$image_config = is_array($image_config) ? $image_config : array();

			if (!empty($image_config['default_image_preload_rules']['rules']) && is_array($image_config['default_image_preload_rules']['rules'])) {
				return true;
			}

			return !empty($config['default_image_optimization_rules']['rules']) && is_array($config['default_image_optimization_rules']['rules']);
		}

		public function optimize($buffer) {
			if (!is_string($buffer)) {
				return $buffer;
			}

			$original_buffer = $buffer;
			$previous_backtrack_limit = ini_get('pcre.backtrack_limit');
			$previous_recursion_limit = ini_get('pcre.recursion_limit');
			$this->setPcreLimit('pcre.backtrack_limit', $this->regexBacktrackLimit());
			$this->setPcreLimit('pcre.recursion_limit', $this->regexRecursionLimit());

			$optimization_failed = false;
			foreach ($this->rules() as $payload) {
				$updated_buffer = $this->applyPayload($buffer, $payload);
				if (!is_string($updated_buffer)) {
					$optimization_failed = true;
					break;
				}
				$buffer = $updated_buffer;
			}

			if (!$optimization_failed) {
				$buffer = $this->insertPreloadLinks($buffer);
				if (!is_string($buffer) || ($original_buffer !== '' && $buffer === '')) {
					$optimization_failed = true;
				}
			}

			if ($optimization_failed) {
				$this->resetPreloadLinks();
				$buffer = $original_buffer;
			}

			$this->restorePcreLimit('pcre.backtrack_limit', $previous_backtrack_limit);
			$this->restorePcreLimit('pcre.recursion_limit', $previous_recursion_limit);

			return $buffer;
		}

		private function rules() {
			$rules = array();
			$template_rule_ids = array();

			if (!empty($this->image_config['default_image_preload_rules']['rules']) && is_array($this->image_config['default_image_preload_rules']['rules'])) {
				foreach ($this->image_config['default_image_preload_rules']['rules'] as $payload) {
					if (!is_array($payload) || empty($payload['rule_id'])) {
						continue;
					}
					$template_rule_ids[(string) $payload['rule_id']] = true;
					$rules[] = $payload;
				}
			}

			if (!empty($this->config['default_image_optimization_rules']['rules']) && is_array($this->config['default_image_optimization_rules']['rules'])) {
				foreach ($this->config['default_image_optimization_rules']['rules'] as $payload) {
					if (!is_array($payload) || empty($payload['rule_id'])) {
						continue;
					}
					if (isset($template_rule_ids[(string) $payload['rule_id']])) {
						continue;
					}
					$rules[] = $payload;
				}
			}

			usort($rules, function($left, $right) {
				return $this->payloadPriority($left) - $this->payloadPriority($right);
			});
			return $rules;
		}

		private function applyPayload($buffer, $payload) {
			$rule = isset($payload['rule']) && is_array($payload['rule']) ? $payload['rule'] : array();
			$regex = isset($rule['search_regex']) ? $rule['search_regex'] : '';
			if ($regex === '' || empty($rule['attributes']) || !is_array($rule['attributes'])) {
				return $buffer;
			}

			$scan_context = $this->protectedScanContext($buffer);
			if (!is_array($scan_context)) {
				return false;
			}

			$scan_buffer = $scan_context['buffer'];
			$protected_ranges = $scan_context['ranges'];
			$matches = array();
			$result = @preg_match_all($regex, $scan_buffer, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE);
			if ($result === false || $this->pregHadError()) {
				$matches = array();
				return false;
			}
			if (!$result) {
				return $buffer;
			}

			$picture_ranges = $this->pictureRanges($scan_buffer);
			if (!is_array($picture_ranges)) {
				return false;
			}
			$output = '';
			$cursor = 0;
			$match_index = 0;

			foreach ($matches as $match) {
				$tag_match = $this->tagMatch($match);
				if (!$tag_match) {
					continue;
				}

				$offset = $tag_match[1];
				$length = strlen($tag_match[0]);
				if ($offset < $cursor) {
					continue;
				}
				$tag = substr($buffer, $offset, $length);
				if (!is_string($tag) || strlen($tag) !== $length) {
					return false;
				}

				if ($this->rangeIntersects($offset, $length, $protected_ranges)) {
					$output .= substr($buffer, $cursor, ($offset + $length) - $cursor);
					$cursor = $offset + $length;
					continue;
				}

				if ($this->shouldSkipMatch($rule, $offset, $picture_ranges)) {
					$output .= substr($buffer, $cursor, ($offset + $length) - $cursor);
					$cursor = $offset + $length;
					continue;
				}

				$preload_info = $this->preloadInfoForIndex($payload, $match_index);
				$replacement = $this->rewriteTag($tag, $payload, $preload_info);
				if (!is_string($replacement)) {
					return false;
				}
				$output .= substr($buffer, $cursor, $offset - $cursor) . $replacement;
				$cursor = $offset + $length;
				$match_index++;
			}

			return $output . substr($buffer, $cursor);
		}

		private function protectedScanContext($buffer) {
			$scan_buffer = $buffer;
			$protected_ranges = array();

			foreach ($this->protectedContentRegexes() as $regex) {
				$matches = array();
				$result = @preg_match_all($regex, $scan_buffer, $matches, PREG_OFFSET_CAPTURE);
				if ($result === false || $this->pregHadError()) {
					return false;
				}
				if (!$result || empty($matches[0])) {
					continue;
				}

				foreach ($matches[0] as $match) {
					if (!is_array($match) || !isset($match[0], $match[1]) || !is_string($match[0])) {
						return false;
					}
					$offset = (int) $match[1];
					$length = strlen($match[0]);
					if ($offset < 0 || $length <= 0) {
						continue;
					}

					$protected_ranges[] = array($offset, $offset + $length);
					$scan_buffer = substr_replace($scan_buffer, str_repeat(' ', $length), $offset, $length);
				}
			}

			return array(
				'buffer' => $scan_buffer,
				'ranges' => $protected_ranges
			);
		}

		private function protectedContentRegexes() {
			$regexes = array(self::DEFAULT_PROTECTED_CONTENT_REGEX);
			if (!empty($this->config['img_buffer_sanitizer_regexes']) && is_array($this->config['img_buffer_sanitizer_regexes'])) {
				foreach ($this->config['img_buffer_sanitizer_regexes'] as $regex) {
					if (is_string($regex) && $regex !== '' && !in_array($regex, $regexes, true)) {
						$regexes[] = $regex;
					}
				}
			}
			return $regexes;
		}

		private function rangeIntersects($offset, $length, $ranges) {
			$end = $offset + $length;
			foreach ($ranges as $range) {
				if ($offset < $range[1] && $end > $range[0]) {
					return true;
				}
			}
			return false;
		}

		private function setPcreLimit($name, $value) {
			if ($value <= 0 || !function_exists('ini_set')) {
				return;
			}
			@ini_set($name, (string) $value);
		}

		private function restorePcreLimit($name, $value) {
			if ($value === false || $value === null || !function_exists('ini_set')) {
				return;
			}
			@ini_set($name, (string) $value);
		}

		private function pregHadError() {
			if (!function_exists('preg_last_error')) {
				return false;
			}

			return preg_last_error() !== PREG_NO_ERROR;
		}

		private function regexBacktrackLimit() {
			return $this->positiveConfigValue(
				'default_image_regex_backtrack_limit',
				self::DEFAULT_REGEX_BACKTRACK_LIMIT
			);
		}

		private function regexRecursionLimit() {
			return $this->positiveConfigValue(
				'default_image_regex_recursion_limit',
				self::DEFAULT_REGEX_RECURSION_LIMIT
			);
		}

		private function positiveConfigValue($key, $default) {
			$value = null;
			if (isset($this->image_config[$key])) {
				$value = $this->image_config[$key];
			} elseif (isset($this->config[$key])) {
				$value = $this->config[$key];
			}

			$value = absint($value);
			if ($value <= 0) {
				$value = $default;
			}

			return $value;
		}

		private function rewriteTag($tag, $payload, $preload_info) {
			if ($this->hasRuntimeMarker($tag)) {
				return $tag;
			}

			$rule = $payload['rule'];
			if ($this->isPictureRule($rule)) {
				return $this->rewritePicture($tag, $payload, $preload_info);
			}

			$attributes = $rule['attributes'];
			$has_preload = is_array($preload_info) && !empty($preload_info['image_urls']);
			if ($has_preload && $this->isImgRule($rule) && $this->hasBrowserSrcAttribute($attributes)) {
				return $this->rewritePreloadedImg($tag, $payload, $preload_info);
			}

			if ($has_preload && $this->isStyleRule($attributes)) {
				$tag = $this->rewriteStyleUrls($tag, $attributes, function($url) use ($payload) {
					return $this->variant_resolver->resolveLarge($url, $this->canUseOptimized($payload))['url'];
				});
				$this->addPreloadLink($this->variant_resolver->resolveLarge($preload_info['image_urls'][0], $this->canUseOptimized($payload))['url'], '', '', $this->preloadMedia($preload_info));
				$tag = $this->rewriteAttributesForRuntime($tag, $attributes, $payload, 'lazy', $preload_info, array('style'));
				$tag = $this->tag_rewriter->addClass($tag, 'bv-image-preloaded');
				return $this->hasObservableAttributes($attributes) ? $this->tag_rewriter->addClass($tag, 'bv-viewport-mod') : $tag;
			}

			if ($has_preload) {
				return $this->rewriteMutationObservedTag($tag, $attributes, $payload, $preload_info);
			}

			if ($this->canLazyload($payload)) {
				if ($this->isImgRule($rule) && $this->hasBrowserSrcAttribute($attributes)) {
					return $this->rewriteLazyImg($tag, $payload);
				}
				if ($this->isStyleRule($attributes)) {
					return $this->rewriteLazyStyle($tag, $attributes, $payload);
				}
				return $this->rewriteMutationObservedTag($tag, $attributes, $payload);
			}

			$tag = $this->rewriteAttributesForRuntime($tag, $attributes, $payload, 'optimize');
			return $this->tag_rewriter->addClass($tag, 'bv-image-optimized');
		}

		private function rewritePreloadedImg($tag, $payload, $preload_info) {
			$attributes = $payload['rule']['attributes'];
			$image_url = $this->browserSrcImageUrl($tag, $attributes);
			if (!$image_url) {
				$image_url = $this->primaryImageUrl($tag, $attributes, $preload_info);
			}
			if (!$image_url) {
				return $tag;
			}

			$can_use_optimized = $this->canUseOptimized($payload);
			$rendering_infos = $this->renderingInfos($preload_info, $image_url);
			$responsive = $this->responsive_source_builder->build($image_url, $rendering_infos, $this->canResize($payload), $can_use_optimized);
			$default_variant = $this->variant_resolver->resolveLarge($image_url, $can_use_optimized);
			$default_url = !empty($responsive['default_url']) ? $responsive['default_url'] : $default_variant['url'];
			$existing_srcset = $this->tag_rewriter->attributeValue($tag, 'srcset');
			if ($existing_srcset !== null && !$this->tag_rewriter->validSrcset($existing_srcset)) {
				return $tag;
			}
			$existing_sizes = $this->tag_rewriter->attributeValue($tag, 'sizes');
			$generated_sizes = !empty($responsive['has_optimized_variant']) ? $responsive['sizes'] : '';
			$can_use_generated_srcset = $existing_sizes || $generated_sizes;
			$generated_srcset = !empty($responsive['has_optimized_variant']) && $can_use_generated_srcset ? $responsive['srcset'] : '';
			$use_original_srcset = $existing_srcset && ($this->canUseOriginalSrcset() || empty($generated_srcset));

			$tag = $this->tag_rewriter->setAttribute($tag, 'src', $default_url);
			if ($existing_srcset && !$use_original_srcset) {
				$tag = $this->tag_rewriter->renameAttribute($tag, 'srcset', 'bv-orig-srcset');
			}
			if (!$use_original_srcset && $generated_srcset) {
				$tag = $this->tag_rewriter->setAttribute($tag, 'srcset', $generated_srcset);
			}
			if (!$existing_sizes && $generated_sizes) {
				$tag = $this->tag_rewriter->setAttribute($tag, 'sizes', $generated_sizes);
			}

			$preload_srcset = $use_original_srcset ? $existing_srcset : $generated_srcset;
			$preload_sizes = $existing_sizes ? $existing_sizes : $generated_sizes;
			$preload_href = $this->preloadHref($default_url, $preload_srcset, $default_variant, $can_use_optimized);
			$this->addPreloadLink($preload_href, $preload_srcset, $preload_sizes, $this->preloadMedia($preload_info));

			$tag = $this->rewriteAttributesForRuntime($tag, $attributes, $payload, 'lazy', $preload_info);
			$tag = $this->tag_rewriter->addClass($tag, 'bv-image-preloaded');
			return $this->hasObservableAttributes($attributes) ? $this->tag_rewriter->addClass($tag, 'bv-viewport-mod') : $tag;
		}

		private function preloadHref($default_url, $preload_srcset, $default_variant, $can_use_optimized) {
			if (!$can_use_optimized || !empty($default_variant['is_optimized']) || !$preload_srcset) {
				return $default_url;
			}

			return '';
		}

		private function rewriteLazyImg($tag, $payload) {
			$attributes = $payload['rule']['attributes'];
			$srcset = $this->tag_rewriter->attributeValue($tag, 'srcset');
			if ($srcset !== null && !$this->tag_rewriter->validSrcset($srcset)) {
				return $tag;
			}
			$image_url = $this->browserSrcImageUrl($tag, $attributes);
			if (!$image_url) {
				$image_url = $this->primaryImageUrl($tag, $attributes);
			}
			if (!$image_url) {
				return $tag;
			}

			$dimensions = $this->lazyImgPlaceholderDimensions($tag, $image_url);
			if (!$dimensions) {
				return $tag;
			}

			$placeholder = $this->placeholderForImage($image_url, $payload, array(), $dimensions[0], $dimensions[1]);

			$tag = $this->tag_rewriter->setAttribute($tag, 'src', $placeholder);
			if ($this->tag_rewriter->attributeValue($tag, 'srcset') !== null) {
				$tag = $this->tag_rewriter->renameAttribute($tag, 'srcset', 'bv-orig-srcset');
			}

			$tag = $this->rewriteAttributesForRuntime($tag, $attributes, $payload, 'lazy');
			$tag = $this->tag_rewriter->addClass($tag, 'bv-image-lazyload');
			return $this->hasObservableAttributes($attributes) ? $this->tag_rewriter->addClass($tag, 'bv-viewport-mod') : $tag;
		}

		private function lazyImgPlaceholderDimensions($tag, $image_url) {
			$width = absint($this->tag_rewriter->attributeValue($tag, 'width'));
			$height = absint($this->tag_rewriter->attributeValue($tag, 'height'));
			if ($width > 0 && $height > 0) {
				return array($width, $height);
			}

			list($width, $height) = $this->responsive_source_builder->placeholderDimensions($image_url);
			$width = absint($width);
			$height = absint($height);
			return ($width > 0 && $height > 0) ? array($width, $height) : false;
		}

		private function rewriteLazyStyle($tag, $attributes, $payload) {
			$tag = $this->rewriteAttributesForRuntime($tag, $attributes, $payload, 'lazy');
			$tag = $this->tag_rewriter->addClass($tag, 'bv-image-lazyload');
			return $this->hasObservableAttributes($attributes) ? $this->tag_rewriter->addClass($tag, 'bv-viewport-mod') : $tag;
		}

		private function rewriteMutationObservedTag($tag, $attributes, $payload, $preload_info = null) {
			$tag = $this->rewriteAttributesForRuntime($tag, $attributes, $payload, 'lazy', $preload_info);
			return $this->tag_rewriter->addClass($tag, 'bv-viewport-mod');
		}

		private function rewritePicture($picture, $payload, $preload_info) {
			if ($this->pictureHasInvalidSrcset($picture)) {
				return $picture;
			}

			$has_preload = is_array($preload_info) && !empty($preload_info['image_urls']);
			if (!$has_preload && $this->canLazyload($payload)) {
				return $this->rewriteLazyPicture($picture, $payload);
			}

			$picture = $this->rewritePictureUrls($picture, $payload, false);
			return $this->tag_rewriter->addClass($picture, 'bv-image-optimized');
		}

		private function rewriteLazyPicture($picture, $payload) {
			$first_url = '';
			$picture = $this->rewritePictureUrls($picture, $payload, true, $first_url);
			if ($first_url) {
				$placeholder = $this->placeholderForImage($first_url, $payload);
				$picture = $this->tag_rewriter->safePregReplaceCallback('~<img\b[^>]*>~is', function($match) use ($placeholder) {
					return $this->tag_rewriter->setAttribute($match[0], 'src', $placeholder);
				}, $picture, 1);
			}
			return $this->tag_rewriter->addClass($picture, 'bv-image-lazyload');
		}

		private function rewritePictureUrls($picture, $payload, $lazyload, &$first_url = '') {
			return $this->tag_rewriter->safePregReplaceCallback('~<(source|img)\b[^>]*>~is', function($match) use ($payload, $lazyload, &$first_url) {
				$tag = $match[0];
				foreach (array('srcset', 'imagesrcset') as $attr) {
					$value = $this->tag_rewriter->attributeValue($tag, $attr);
					if ($value === null) {
						continue;
					}
					$new_value = $this->tag_rewriter->replaceSrcsetUrls($value, function($url) use ($payload, &$first_url) {
						$first_url = $first_url ?: $url;
						return $this->variant_resolver->resolveLarge($url, $this->canUseOptimized($payload))['url'];
					});
					if ($lazyload) {
						$tag = $this->tag_rewriter->setAttribute($tag, 'bv-orig-' . $attr, $new_value);
						$tag = $this->tag_rewriter->removeAttribute($tag, $attr);
					} else {
						$tag = $this->tag_rewriter->setAttribute($tag, $attr, $new_value);
					}
				}

				$value = $this->tag_rewriter->attributeValue($tag, 'src');
				if ($value !== null) {
					$single_url = $this->tag_rewriter->singleImageUrl($value);
					$first_url = $first_url ?: $single_url;
					$new_value = $this->tag_rewriter->replaceSingleImageUrl($value, function($url) use ($payload) {
						return $this->variant_resolver->resolveLarge($url, $this->canUseOptimized($payload))['url'];
					});
					if ($lazyload) {
						$tag = $this->tag_rewriter->setAttribute($tag, 'bv-orig-src', $new_value);
						$tag = $this->tag_rewriter->removeAttribute($tag, 'src');
					} else {
						$tag = $this->tag_rewriter->setAttribute($tag, 'src', $new_value);
					}
				}

				return $tag;
			}, $picture);
		}

		private function pictureHasInvalidSrcset($picture) {
			$invalid = false;
			$this->tag_rewriter->safePregReplaceCallback('~<(?:source|img)\b[^>]*>~is', function($match) use (&$invalid) {
				foreach (array('srcset', 'imagesrcset') as $attr) {
					$value = $this->tag_rewriter->attributeValue($match[0], $attr);
					if ($value !== null && !$this->tag_rewriter->validSrcset($value)) {
						$invalid = true;
					}
				}
				return $match[0];
			}, (string) $picture);
			return $invalid;
		}

		private function placeholderForImage($image_url, $payload, $rendering_infos = array(), $width = 0, $height = 0) {
			$large_variant = $this->variant_resolver->resolveLarge($image_url, $this->canUseOptimized($payload));
			$resized_infos = $this->variant_resolver->resizedInfos($image_url, $this->canResize($payload), $this->canUseOptimized($payload));
			if ($width <= 0 || $height <= 0) {
				list($width, $height) = $this->responsive_source_builder->placeholderDimensions($image_url, $rendering_infos);
			}
			return $this->tag_rewriter->svgPlaceholder($large_variant['url'], $resized_infos, $width, $height);
		}

		private function rewriteAttributesForRuntime($tag, $attributes, $payload, $mode, $preload_info = null, $skip_actions = array()) {
			$skip_actions = array_flip($skip_actions);
			foreach ($attributes as $attribute) {
				if (empty($attribute['name']) || empty($attribute['match_type'])) {
					continue;
				}
				$action = $this->attributeAction($attribute);
				if (isset($skip_actions[$action]) || ($mode !== 'optimize' && $this->isBrowserManagedAttribute($attribute))) {
					continue;
				}
				$name = $attribute['name'];
				$value = $this->tag_rewriter->attributeValue($tag, $name);
				if ($value === null) {
					continue;
				}

				$callback = ($mode === 'optimize' || $action === 'optimize') ?
					function($url) use ($payload) {
						return $this->variant_resolver->resolveLarge($url, $this->canUseOptimized($payload))['url'];
					} :
					function($url) use ($payload, $preload_info) {
						$rendering_infos = $preload_info ? $this->renderingInfos($preload_info, $url) : array();
						return $this->placeholderForImage($url, $payload, $rendering_infos);
					};

				switch ($attribute['match_type']) {
					case 'attr_srcset':
						if (!$this->tag_rewriter->validSrcset($value)) {
							continue 2;
						}
						$new_value = $this->tag_rewriter->replaceSrcsetUrls($value, $callback);
						break;
					case 'attr_json':
						// JSON is used as application configuration. Keep it byte-for-byte instead
						// of risking unrelated semantic changes while re-encoding the document.
						$new_value = $value;
						break;
					case 'style':
						$new_value = $this->tag_rewriter->replaceStyleUrls($value, $callback);
						break;
					default:
						$new_value = $this->tag_rewriter->replaceSingleImageUrl($value, $callback);
						break;
				}
				$tag = $this->tag_rewriter->setAttribute($tag, $name, $new_value);
			}
			return $tag;
		}

		private function rewriteStyleUrls($tag, $attributes, $callback) {
			foreach ($attributes as $attribute) {
				if ($this->attributeAction($attribute) !== 'style') {
					continue;
				}
				$name = $attribute['name'];
				$value = $this->tag_rewriter->attributeValue($tag, $name);
				if ($value === null) {
					continue;
				}
				$tag = $this->tag_rewriter->setAttribute($tag, $name, $this->tag_rewriter->replaceStyleUrls($value, $callback));
			}
			return $tag;
		}

		private function attributeAction($attribute) {
			if (!empty($attribute['runtime_action'])) {
				return (string) $attribute['runtime_action'];
			}

			$name = strtolower(isset($attribute['name']) ? $attribute['name'] : '');
			$type = isset($attribute['match_type']) ? $attribute['match_type'] : '';
			if ($type === 'picture') {
				return 'picture';
			}
			if ($type === 'style') {
				return 'style';
			}
			if ($name === 'src' && $type === 'attr_url') {
				return 'browser_src';
			}
			if (in_array($name, array('srcset', 'imagesrcset'), true) && $type === 'attr_srcset') {
				return 'browser_srcset';
			}
			if ($type === 'attr_srcset') {
				return 'optimize';
			}

			return 'placeholder';
		}

		private function isBrowserManagedAttribute($attribute) {
			return in_array($this->attributeAction($attribute), array('browser_src', 'browser_srcset', 'picture'), true);
		}

		private function hasBrowserSrcAttribute($attributes) {
			foreach ($attributes as $attribute) {
				if ($this->attributeAction($attribute) === 'browser_src') {
					return true;
				}
			}
			return false;
		}

		private function hasObservableAttributes($attributes) {
			foreach ($attributes as $attribute) {
				if (!$this->isBrowserManagedAttribute($attribute) && $this->attributeAction($attribute) === 'placeholder') {
					return true;
				}
			}
			return false;
		}

		private function primaryImageUrl($tag, $attributes, $preload_info = null) {
			if (is_array($preload_info) && !empty($preload_info['image_urls'][0])) {
				return $preload_info['image_urls'][0];
			}

			foreach ($attributes as $attribute) {
				$urls = $this->imageUrlsForAttribute($tag, $attribute);
				if (!empty($urls[0])) {
					return $urls[0];
				}
			}
			return '';
		}

		private function browserSrcImageUrl($tag, $attributes) {
			foreach ($attributes as $attribute) {
				if ($this->attributeAction($attribute) !== 'browser_src') {
					continue;
				}
				$value = $this->tag_rewriter->attributeValue($tag, $attribute['name']);
				if ($value === null) {
					continue;
				}
				$urls = $this->tag_rewriter->singleImageUrls($value);
				if (!empty($urls[0])) {
					return $urls[0];
				}
			}
			return '';
		}

		private function imageUrlsForAttribute($tag, $attribute) {
			if (empty($attribute['name']) || empty($attribute['match_type'])) {
				return array();
			}

			$value = $this->tag_rewriter->attributeValue($tag, $attribute['name']);
			if ($value === null) {
				return array();
			}

			switch ($attribute['match_type']) {
				case 'attr_srcset':
					return $this->tag_rewriter->srcsetUrls($value);
				case 'attr_json':
					return array();
				case 'style':
					return $this->tag_rewriter->styleUrls($value);
				default:
					return $this->tag_rewriter->singleImageUrls($value);
			}
		}

		private function preloadMedia($preload_info) {
			if (!is_array($preload_info) || !isset($preload_info['media']) || !is_string($preload_info['media'])) {
				return '';
			}

			return $preload_info['media'];
		}

		private function addPreloadLink($href, $srcset = '', $sizes = '', $media = '') {
			if ((!$href && !$srcset) || !$this->url_matched) {
				return;
			}

			$key = md5($href . '|' . $srcset . '|' . $sizes . '|' . $media);
			if (isset($this->preload_link_keys[$key])) {
				return;
			}
			$this->preload_link_keys[$key] = true;

			$link = '<link rel="preload" as="image" class="bv-preload"';
			if ($href) {
				$link .= ' href="' . esc_url($href) . '"';
			}
			if ($srcset) {
				$link .= ' imagesrcset="' . esc_attr($srcset) . '"';
			}
			if ($sizes) {
				$link .= ' imagesizes="' . esc_attr($sizes) . '"';
			}
			if ($media) {
				$link .= ' media="' . esc_attr($media) . '"';
			}
			$link .= '>';
			$this->preload_links[] = $link;
		}

		private function resetPreloadLinks() {
			$this->preload_links = array();
			$this->preload_link_keys = array();
		}

		private function insertPreloadLinks($buffer) {
			if (empty($this->preload_links)) {
				return $buffer;
			}

			$links = implode("\n", $this->preload_links) . "\n";
			if (preg_match('~<head\b[^>]*>~i', $buffer, $matches)) {
				return ALHelper::safeStrReplaceFirst($matches[0], $matches[0] . "\n" . $links, $buffer);
			}
			return $links . $buffer;
		}

		private function preloadInfoForIndex($payload, $index) {
			if (empty($payload['preload_indexes']) || !is_array($payload['preload_indexes'])) {
				return false;
			}

			foreach ($payload['preload_indexes'] as $preload_info) {
				if (isset($preload_info['index']) && absint($preload_info['index']) === absint($index)) {
					return $preload_info;
				}
			}
			return false;
		}

		private function renderingInfos($preload_info, $image_url) {
			if (empty($preload_info['rendering_infos_by_url']) || !is_array($preload_info['rendering_infos_by_url'])) {
				return array();
			}

			if (isset($preload_info['rendering_infos_by_url'][$image_url]) && is_array($preload_info['rendering_infos_by_url'][$image_url])) {
				return $preload_info['rendering_infos_by_url'][$image_url];
			}

			$absolute_url = $this->variant_resolver->absoluteUrl($image_url);
			return isset($preload_info['rendering_infos_by_url'][$absolute_url]) && is_array($preload_info['rendering_infos_by_url'][$absolute_url]) ?
				$preload_info['rendering_infos_by_url'][$absolute_url] : array();
		}

		private function tagMatch($match) {
			if (isset($match['tag']) && is_array($match['tag'])) {
				return $match['tag'];
			}
			return isset($match[0]) && is_array($match[0]) ? $match[0] : false;
		}

		private function shouldSkipMatch($rule, $offset, $picture_ranges) {
			if (strtolower(isset($rule['tag']) ? $rule['tag'] : '') !== 'img') {
				return false;
			}

			foreach ($picture_ranges as $range) {
				if ($offset >= $range[0] && $offset <= $range[1]) {
					return true;
				}
			}
			return false;
		}

		private function pictureRanges($buffer) {
			$ranges = array();
			$result = @preg_match_all('~<picture\b.*?</picture>~is', $buffer, $matches, PREG_OFFSET_CAPTURE);
			if ($result === false || $this->pregHadError()) {
				return false;
			}
			if ($result) {
				foreach ($matches[0] as $match) {
					$ranges[] = array($match[1], $match[1] + strlen($match[0]));
				}
			}
			return $ranges;
		}

		private function hasRuntimeMarker($tag) {
			foreach (array('bv-image-preloaded', 'bv-image-lazyload', 'bv-viewport-mod', 'bv-image-optimized', 'bv-orig-srcset', 'bv-orig-src') as $marker) {
				if (strpos($tag, $marker) !== false) {
					return true;
				}
			}
			return false;
		}

		private function isPictureRule($rule) {
			return strtolower(isset($rule['tag']) ? $rule['tag'] : '') === 'picture';
		}

		private function isImgRule($rule) {
			return strtolower(isset($rule['tag']) ? $rule['tag'] : '') === 'img';
		}

		private function isStyleRule($attributes) {
			foreach ($attributes as $attribute) {
				if (isset($attribute['match_type']) && $attribute['match_type'] === 'style') {
					return true;
				}
			}
			return false;
		}

		private function canLazyload($payload) {
			return !isset($payload['can_lazyload']) || $payload['can_lazyload'] !== false;
		}

		private function canResize($payload) {
			return !isset($payload['can_resize_images']) || $payload['can_resize_images'] !== false;
		}

		private function canUseOptimized($payload) {
			return !isset($payload['can_use_webp']) || $payload['can_use_webp'] !== false;
		}

		private function canUseOriginalSrcset() {
			return !empty($this->image_config['can_use_srcset']) || !empty($this->config['can_use_srcset']);
		}

		private function payloadPriority($payload) {
			if (isset($payload['rule']['priority'])) {
				return absint($payload['rule']['priority']);
			}
			return 100000;
		}
	}
endif;
