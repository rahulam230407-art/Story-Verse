<?php

if (!class_exists('ALImageTagRewriter')) :

	class ALImageTagRewriter {

		public function tagName($tag) {
			if (preg_match('~<\s*([a-zA-Z0-9:-]+)~', $tag, $matches)) {
				return strtolower($matches[1]);
			}
			return '';
		}

		public function addClass($tag, $class_name) {
			$classes = $this->attributeValue($tag, 'class');
			if ($classes === null || trim($classes) === '') {
				return $this->setAttribute($tag, 'class', $class_name);
			}

			$class_list = preg_split('/\s+/', trim($classes));
			if (!in_array($class_name, $class_list, true)) {
				$class_list[] = $class_name;
			}
			return $this->setAttribute($tag, 'class', implode(' ', $class_list));
		}

		public function attributeValue($tag, $attr_name) {
			$attrs = $this->attributes($tag);
			$key = strtolower($attr_name);
			return array_key_exists($key, $attrs) ? $attrs[$key]['value'] : null;
		}

		public function setAttribute($tag, $attr_name, $value) {
			$opening_tag = $this->openingTag($tag);
			if ($opening_tag === '') {
				return $tag;
			}

			$attrs = $this->attributes($opening_tag);
			$attrs[strtolower($attr_name)] = array('name' => $attr_name, 'value' => (string) $value);
			$new_opening_tag = $this->buildOpeningTag($opening_tag, $attrs);
			return ALHelper::safeStrReplace($opening_tag, $new_opening_tag, $tag);
		}

		public function removeAttribute($tag, $attr_name) {
			$opening_tag = $this->openingTag($tag);
			if ($opening_tag === '') {
				return $tag;
			}

			$attrs = $this->attributes($opening_tag);
			unset($attrs[strtolower($attr_name)]);
			$new_opening_tag = $this->buildOpeningTag($opening_tag, $attrs);
			return ALHelper::safeStrReplace($opening_tag, $new_opening_tag, $tag);
		}

		public function renameAttribute($tag, $from_attr, $to_attr) {
			$value = $this->attributeValue($tag, $from_attr);
			if ($value === null) {
				return $tag;
			}

			$tag = $this->removeAttribute($tag, $from_attr);
			return $this->setAttribute($tag, $to_attr, $value);
		}

		public function attributes($tag) {
			$opening_tag = $this->openingTag($tag);
			$tag_name = $this->tagName($opening_tag);
			$attr_text = preg_replace('~^<\s*' . preg_quote($tag_name, '~') . '\b~i', '', $opening_tag);
			$attr_text = preg_replace('~/?\s*>$~', '', $attr_text);
			$attrs = array();

			if (preg_match_all('~\s+([^\s=\/>]+)(?:\s*=\s*(["\'])(.*?)\2|\s*=\s*([^\s"\'>]+))?~s', $attr_text, $matches, PREG_SET_ORDER)) {
				foreach ($matches as $match) {
					$name = $match[1];
					$value = isset($match[3]) && $match[3] !== '' ? $match[3] : (isset($match[4]) ? $match[4] : '');
					$attrs[strtolower($name)] = array('name' => $name, 'value' => html_entity_decode($value, ENT_QUOTES | ENT_HTML5));
				}
			}

			return $attrs;
		}

		public function openingTag($tag) {
			$tag = (string) $tag;
			$length = strlen($tag);
			$quote = '';
			$start = strpos($tag, '<');
			if ($start === false) {
				return '';
			}

			for ($index = $start; $index < $length; $index++) {
				$char = $tag[$index];
				if (($char === '"' || $char === "'") && ($index === 0 || $tag[$index - 1] !== '\\')) {
					$quote = $quote === $char ? '' : ($quote === '' ? $char : $quote);
					continue;
				}
				if ($char === '>' && $quote === '') {
					return substr($tag, $start, $index - $start + 1);
				}
			}

			return '';
		}

		public function singleImageUrls($value) {
			$url = $this->singleImageUrl($value);
			return $url === null ? array() : array($url);
		}

		public function singleImageUrl($value) {
			$url = trim((string) $value);
			return $url === '' || $this->isDataImage($url) ? null : $url;
		}

		public function replaceSingleImageUrl($value, $callback) {
			$source = (string) $value;
			$url = $this->singleImageUrl($source);
			if ($url === null || !is_callable($callback)) {
				return $source;
			}

			$replacement = call_user_func($callback, $url);
			if (!is_string($replacement)) {
				return $source;
			}
			return $replacement;
		}

		public function srcsetUrls($value) {
			$candidates = $this->srcsetCandidates($value);
			if ($candidates === false) {
				return array();
			}
			$urls = array();
			foreach ($candidates as $candidate) {
				if (!$this->isDataImage($candidate['url'])) {
					$urls[] = $candidate['url'];
				}
			}
			return array_values(array_unique($urls));
		}

		public function srcsetWidthCandidates($value) {
			$parsed = $this->srcsetCandidates($value);
			if ($parsed === false) {
				return array();
			}
			$candidates = array();
			foreach ($parsed as $candidate) {
				if ($this->isDataImage($candidate['url'])) {
					continue;
				}
				foreach ($candidate['descriptors'] as $descriptor) {
					if (substr(strtolower($descriptor), -1) === 'w') {
						$candidates[] = array('url' => $candidate['url'], 'width' => absint(substr($descriptor, 0, -1)));
						break;
					}
				}
			}
			return $candidates;
		}

		public function validSrcset($value) {
			return $this->srcsetCandidates($value) !== false;
		}

		public function replaceSrcsetUrls($value, $callback) {
			$source = (string) $value;
			$candidates = $this->srcsetCandidates($source);
			if ($candidates === false || !is_callable($callback)) {
				return $source;
			}
			for ($index = count($candidates) - 1; $index >= 0; $index--) {
				$candidate = $candidates[$index];
				if ($this->isDataImage($candidate['url'])) {
					continue;
				}
				$new_url = call_user_func($callback, $candidate['url']);
				if (!is_string($new_url)) {
					return (string) $value;
				}
				$source = substr_replace($source, $new_url, $candidate['start'], $candidate['finish'] - $candidate['start']);
			}
			return $source;
		}

		public function styleUrls($value) {
			$urls = array();
			if (preg_match_all('~url\(\s*(?:"([^"]*)"|\'([^\']*)\'|([^)]*?))\s*\)~i', (string) $value, $matches, PREG_SET_ORDER)) {
				foreach ($matches as $match) {
					$url = isset($match[1]) && $match[1] !== '' ? $match[1] : (isset($match[2]) && $match[2] !== '' ? $match[2] : (isset($match[3]) ? $match[3] : ''));
					$url = trim($url);
					if ($url !== '' && !$this->isDataImage($url)) {
						$urls[] = $url;
					}
				}
			}
			return array_values(array_unique($urls));
		}

		public function replaceStyleUrls($value, $callback) {
			if (!is_callable($callback)) {
				return (string) $value;
			}
			return $this->safePregReplaceCallback('~url\(\s*(?:"([^"]*)"|\'([^\']*)\'|([^)]*?))\s*\)~i', function($match) use ($callback) {
				$url = isset($match[1]) && $match[1] !== '' ? $match[1] : (isset($match[2]) && $match[2] !== '' ? $match[2] : (isset($match[3]) ? $match[3] : ''));
				$url = trim($url);
				if ($url === '' || $this->isDataImage($url)) {
					return $match[0];
				}
				return 'url("' . call_user_func($callback, $url) . '")';
			}, (string) $value);
		}

		public function safePregReplaceCallback($pattern, $callback, $subject, $limit = -1) {
			if (!is_string($pattern) || !is_callable($callback) || !is_string($subject) || !is_int($limit)) {
				return $subject;
			}

			$updated_subject = @preg_replace_callback($pattern, $callback, $subject, $limit);
			if (!is_string($updated_subject)) {
				return $subject;
			}
			if (function_exists('preg_last_error') && preg_last_error() !== PREG_NO_ERROR) {
				return $subject;
			}

			return $updated_subject;
		}

		public function svgPlaceholder($image_url, $resized_infos = '', $width = 0, $height = 0) {
			$width = absint($width);
			$height = absint($height);
			$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . max(1, $width) . ' ' . max(1, $height) . '"';
			if ($width > 0 && $height > 0) {
				$svg .= ' width="' . $width . '" height="' . $height . '"';
			}
			$svg .= ' bv-img-url="' . esc_attr($image_url) . '"';
			if ($resized_infos !== '') {
				$svg .= ' bv-resized-infos="' . esc_attr(base64_encode($resized_infos)) . '"';
			}
			$svg .= '></svg>';
			return 'data:image/svg+xml;base64,' . base64_encode($svg);
		}

		private function buildOpeningTag($opening_tag, $attrs) {
			$tag_name = $this->tagName($opening_tag);
			if ($tag_name === '') {
				return $opening_tag;
			}

			$parts = array('<' . $tag_name);
			foreach ($attrs as $attr) {
				$name = $attr['name'];
				$value = $attr['value'];
				$parts[] = $name . '="' . esc_attr($value) . '"';
			}

			$self_closing = preg_match('~/\s*>$~', $opening_tag);
			return implode(' ', $parts) . ($self_closing ? ' />' : '>');
		}

		private function srcsetCandidates($value) {
			// A comma belongs to the URL until URL collection ends at ASCII whitespace;
			// only trailing URL commas or commas after descriptors delimit candidates.
			$source = (string) $value;
			$length = strlen($source);
			$position = 0;
			$candidates = array();
			while ($position < $length) {
				while ($position < $length && ($this->isAsciiWhitespace($source[$position]) || $source[$position] === ',')) {
					$position++;
				}
				if ($position >= $length) {
					break;
				}
				$url_start = $position;
				while ($position < $length && !$this->isAsciiWhitespace($source[$position])) {
					$position++;
				}
				$url_end = $position;
				$url = substr($source, $url_start, $url_end - $url_start);
				if ($url !== '' && substr($url, -1) === ',') {
					while ($url !== '' && substr($url, -1) === ',') {
						$url = substr($url, 0, -1);
					}
					if ($url === '') {
						return false;
					}
					$candidates[] = array('url' => $url, 'start' => $url_start, 'finish' => $url_start + strlen($url), 'descriptors' => array());
					continue;
				}

				while ($position < $length && $this->isAsciiWhitespace($source[$position])) {
					$position++;
				}
				$descriptors = array();
				$token = '';
				$paren_depth = 0;
				while ($position < $length) {
					$char = $source[$position];
					if ($char === ',' && $paren_depth === 0) {
						if ($token !== '') {
							$descriptors[] = $token;
						}
						$token = '';
						$position++;
						break;
					}
					if ($this->isAsciiWhitespace($char) && $paren_depth === 0) {
						if ($token !== '') {
							$descriptors[] = $token;
							$token = '';
						}
					} elseif ($char === '(') {
						$paren_depth++;
						$token .= $char;
					} elseif ($char === ')') {
						if ($paren_depth === 0) {
							return false;
						}
						$paren_depth--;
						$token .= $char;
					} else {
						$token .= $char;
					}
					$position++;
				}
				if ($token !== '') {
					$descriptors[] = $token;
				}
				if ($paren_depth !== 0 || !$this->validSrcsetDescriptors($descriptors)) {
					return false;
				}
				$candidates[] = array('url' => $url, 'start' => $url_start, 'finish' => $url_end, 'descriptors' => $descriptors);
			}
			return empty($candidates) ? false : $candidates;
		}

		private function validSrcsetDescriptors($descriptors) {
			$seen = array();
			foreach ($descriptors as $descriptor) {
				$kind = strtolower(substr($descriptor, -1));
				$value = substr($descriptor, 0, -1);
				$valid = false;
				if ($kind === 'w' || $kind === 'h') {
					$valid = $value !== '' && strspn($value, '0123456789') === strlen($value) && (int) $value > 0;
				} elseif ($kind === 'x') {
					$number = (float) $value;
					$valid = $value !== '' && is_numeric($value) && is_finite($number) && $number > 0;
				}
				if (!$valid || isset($seen[$kind])) {
					return false;
				}
				$seen[$kind] = true;
			}
			return !(isset($seen['w']) && isset($seen['x'])) && (!isset($seen['h']) || isset($seen['w']));
		}

		private function isAsciiWhitespace($char) {
			return $char === "\t" || $char === "\n" || $char === "\f" || $char === "\r" || $char === ' ';
		}

		private function isDataImage($url) {
			return stripos(trim((string) $url), 'data:image/') === 0;
		}
	}
endif;
